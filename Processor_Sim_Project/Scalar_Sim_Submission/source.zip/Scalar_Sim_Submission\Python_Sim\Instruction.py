class Instruction :

    def __init__(self, opCode, operand1, operand2, operand3, instructionNumber) :
        self.opCode = opCode
        self.operand1 = operand1
        self.operand2 = operand2
        self.operand3 = operand3
        self.instructionNumber = instructionNumber